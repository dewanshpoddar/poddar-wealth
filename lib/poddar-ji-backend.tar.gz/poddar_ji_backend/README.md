# Poddar Ji — LIC Insurance Advisor Backend

## Quick Start
```
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```
Open http://localhost:8000/docs for interactive API documentation.

## 8 Calculators
- Premium, Maturity, Surrender, Death Benefit, Loan, Paid-Up, Tax, IRR

## 12 API Endpoints
- Plan lookup, lineage, bonus rates, search, recommend, compare

## Data: 399 plans × 77 fields | 63 active | 336 withdrawn
