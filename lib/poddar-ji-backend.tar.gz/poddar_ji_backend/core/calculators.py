"""
PODDAR JI — LIC Calculator Engine
Every financial calculation for LIC plans.
This module is the computational heart — no hallucination, only math.
"""
from typing import Optional, Dict, Any
from dataclasses import dataclass
import math


@dataclass
class PremiumResult:
    annual: float
    half_yearly: float
    quarterly: float
    monthly: float
    gst_first_year: float
    gst_renewal: float
    total_first_year: float
    total_outgo: float  # total premiums over full term
    mode_rebate_yearly_pct: float = 2.0


@dataclass
class MaturityResult:
    basic_sa: float
    total_srb: float
    fab_estimate: float
    total_maturity: float
    years: int
    bonus_rate_used: float
    disclaimer: str = "Bonuses are not guaranteed. Projected based on current declared rates."


@dataclass
class SurrenderResult:
    gsv: float
    ssv_estimate: float
    payable: float
    premiums_paid_total: float
    loss_on_surrender: float
    recommendation: str
    irr_if_surrendered: float


@dataclass
class DeathBenefitResult:
    sa_on_death: float
    vested_bonuses: float
    fab_estimate: float
    total_death_benefit: float
    min_guarantee: float
    formula_used: str


@dataclass
class LoanResult:
    max_loan: float
    interest_rate: float
    interest_mode: str
    surrender_value_basis: float


@dataclass
class PaidUpResult:
    original_sa: float
    paid_up_sa: float
    premiums_paid: int
    total_payable: int
    vested_bonuses: float
    death_benefit_paid_up: float
    maturity_paid_up: float


@dataclass
class TaxResult:
    section_80c_eligible: bool
    max_80c_deduction: float
    actual_deduction: float
    section_10_10d_exempt: bool
    exemption_condition: str
    gst_rate: float
    tds_applicable: bool
    tds_note: str


@dataclass
class IRRResult:
    irr_percent: float
    total_invested: float
    total_returned: float
    wealth_multiple: float
    equivalent_fd_rate: str
    verdict: str


class LICCalculatorEngine:
    """
    Core calculator for all LIC plan computations.
    Uses plan parameters from the knowledge base.
    """

    # ---- PREMIUM CALCULATOR ----
    def calculate_premium(
        self,
        plan: Dict[str, Any],
        age: int,
        term: int,
        sa: float,
        mode: str = "yearly"
    ) -> PremiumResult:
        """
        Calculate premium for a given plan, age, term, and SA.
        Uses premium rate per 1000 SA if available, otherwise estimates.
        """
        plan_no = plan.get("Plan No", "")
        premium_type = str(plan.get("Premium Type", ""))
        gst_first = plan.get("gst_first_yr_pct") or 4.5
        gst_renewal = plan.get("gst_renewal_pct") or 2.25

        # Check if we have exact premium rates in the plan data
        # For now, use tabular rate estimation based on plan type
        rate_per_1000 = self._get_premium_rate(plan, age, term)

        annual = (sa / 1000) * rate_per_1000

        # Apply High SA rebate
        annual = self._apply_sa_rebate(annual, sa, plan)

        # Mode-wise premiums with rebates
        half_yearly = annual * 0.51  # ~1% rebate on half-yearly
        quarterly = annual * 0.26   # No rebate on quarterly
        monthly = annual * 0.0875   # No rebate, slight loading

        gst_fy = annual * gst_first / 100
        gst_rn = annual * gst_renewal / 100

        # Determine PPT
        ppt = self._get_ppt(plan, term)
        total_outgo = annual * ppt

        return PremiumResult(
            annual=round(annual, 0),
            half_yearly=round(half_yearly, 0),
            quarterly=round(quarterly, 0),
            monthly=round(monthly, 0),
            gst_first_year=round(gst_fy, 0),
            gst_renewal=round(gst_rn, 0),
            total_first_year=round(annual + gst_fy, 0),
            total_outgo=round(total_outgo, 0),
        )

    def _get_premium_rate(self, plan: Dict, age: int, term: int) -> float:
        """Get premium rate per 1000 SA based on plan type and age/term."""
        category = str(plan.get("Category", ""))
        plan_no = str(plan.get("Plan No", ""))

        # Known rates from official brochures (per 1000 SA for standard lives)
        known_rates = {
            # New Jeevan Anand 715: from brochure (rates per 2L SA, convert to per 1000)
            "715": {(20, 15): 81.1, (20, 25): 46.7, (20, 35): 32.6,
                    (30, 15): 84.4, (30, 25): 49.1, (30, 35): 34.8,
                    (40, 15): 90.1, (40, 25): 53.6, (40, 35): 39.6,
                    (50, 15): 99.6, (50, 25): 62.0},
        }

        if plan_no in known_rates:
            rates = known_rates[plan_no]
            # Find closest match
            best_key = min(rates.keys(), key=lambda k: abs(k[0] - age) + abs(k[1] - term))
            return rates[best_key]

        # Estimate based on plan category and mortality
        base_rate = self._estimate_base_rate(category, age, term)
        return base_rate

    def _estimate_base_rate(self, category: str, age: int, term: int) -> float:
        """
        Estimate premium rate when exact tables not available.
        Based on LIC's general pricing patterns.
        CLEARLY MARKED AS ESTIMATE — not from official tables.
        """
        # Base mortality cost increases with age
        mortality_factor = 1.0 + (age - 25) * 0.015

        if "Endowment" in category:
            # Endowment: savings + protection
            if term <= 15:
                base = 65.0
            elif term <= 25:
                base = 42.0
            else:
                base = 32.0
        elif "Money Back" in category:
            # Money back: slightly higher due to periodic payouts
            base = 55.0 if term <= 20 else 45.0
        elif "Whole Life" in category:
            # Limited pay whole life
            base = 70.0
        elif "Term" in category:
            # Pure term: very low
            base = 3.0 + age * 0.15
            return base * mortality_factor
        elif "Child" in category:
            base = 55.0
        elif "Pension" in category or "Annuity" in category:
            return 0  # Single premium plans
        else:
            base = 50.0

        return base * mortality_factor

    def _apply_sa_rebate(self, premium: float, sa: float, plan: Dict) -> float:
        """Apply High Sum Assured rebate."""
        rebate_str = str(plan.get("High SA Rebate", ""))

        # Standard LIC rebate structure for post-2024 plans
        if sa >= 1000000:  # 10L+
            return premium - (sa / 1000) * 4.0  # ₹4 per 1000 BSA
        elif sa >= 500000:  # 5L-10L
            return premium - (sa / 1000) * 2.5  # ₹2.5 per 1000 BSA
        return premium

    def _get_ppt(self, plan: Dict, term: int) -> int:
        """Get Premium Paying Term."""
        ppt_str = str(plan.get("Premium Paying Term", ""))
        if "Equal to Policy Term" in ppt_str or "Equal to" in ppt_str:
            return term
        if "minus 3" in ppt_str:
            return term - 3
        # Try to parse number
        import re
        m = re.search(r'(\d+)\s*years', ppt_str)
        if m:
            return int(m.group(1))
        # Limited premium plans
        if "Single" in str(plan.get("Premium Type", "")):
            return 1
        return term

    # ---- MATURITY CALCULATOR ----
    def calculate_maturity(
        self,
        plan: Dict[str, Any],
        sa: float,
        term: int,
        bonus_rate: Optional[float] = None,
        fab_rate: Optional[float] = None
    ) -> MaturityResult:
        """
        Calculate projected maturity value.
        bonus_rate: per 1000 SA per year (from LIC bonus circular)
        """
        category = str(plan.get("Category", ""))

        # Term plans have no maturity
        if "Term" in category:
            return MaturityResult(
                basic_sa=sa, total_srb=0, fab_estimate=0,
                total_maturity=0, years=term, bonus_rate_used=0,
                disclaimer="Pure term plan — no maturity benefit payable on survival."
            )

        # Get bonus rate
        if bonus_rate is None:
            bonus_rate = self._get_default_bonus_rate(plan, term)

        # Participating plan: SA + SRB + FAB
        ga_str = str(plan.get("Guaranteed Additions", ""))
        if "Non-par" in ga_str or "GA" in ga_str or "₹50" in ga_str:
            # Non-participating with Guaranteed Additions
            ga_per_1000 = 50  # Default GA rate
            import re
            m = re.search(r'₹(\d+)', ga_str)
            if m:
                ga_per_1000 = int(m.group(1))
            total_ga = (sa / 1000) * ga_per_1000 * term
            return MaturityResult(
                basic_sa=sa, total_srb=total_ga, fab_estimate=0,
                total_maturity=sa + total_ga, years=term,
                bonus_rate_used=ga_per_1000,
                disclaimer="Non-participating plan. Guaranteed Additions are fixed at plan inception."
            )

        # Standard participating plan
        total_srb = (sa / 1000) * bonus_rate * term
        fab = self._estimate_fab(sa, term)

        return MaturityResult(
            basic_sa=sa,
            total_srb=round(total_srb, 0),
            fab_estimate=round(fab, 0),
            total_maturity=round(sa + total_srb + fab, 0),
            years=term,
            bonus_rate_used=bonus_rate,
            disclaimer="Bonuses are not guaranteed. Projected based on FY2024-25 declared rates."
        )

    def _get_default_bonus_rate(self, plan: Dict, term: int) -> float:
        """Get default bonus rate from plan data."""
        bonus_str = str(plan.get("Bonus Rate FY2024-25 (per ₹1000 SA)", ""))
        import re
        # Extract the highest rate mentioned
        rates = re.findall(r'(\d+)', bonus_str)
        if rates:
            return float(rates[-1])  # Take the highest (longest term)
        # Default fallback
        if term <= 15:
            return 37
        elif term <= 20:
            return 41
        else:
            return 45

    def _estimate_fab(self, sa: float, term: int) -> float:
        """Estimate Final Additional Bonus."""
        if term < 15:
            return 0
        # FAB typically ranges from ₹20-200 per 1000 SA depending on term
        if term >= 25:
            return (sa / 1000) * 150
        elif term >= 20:
            return (sa / 1000) * 100
        else:
            return (sa / 1000) * 50

    # ---- SURRENDER VALUE CALCULATOR ----
    def calculate_surrender(
        self,
        plan: Dict[str, Any],
        policy_year: int,
        annual_premium: float,
        sa: float,
        bonus_rate: float = 42,
        term: int = 20
    ) -> SurrenderResult:
        """Calculate Guaranteed and Special Surrender Value."""
        category = str(plan.get("Category", ""))

        # Term plans have no surrender value
        if "Term" in category:
            return SurrenderResult(
                gsv=0, ssv_estimate=0, payable=0,
                premiums_paid_total=annual_premium * policy_year,
                loss_on_surrender=annual_premium * policy_year,
                recommendation="Term plans have no surrender value. All premiums are lost on surrender.",
                irr_if_surrendered=-100
            )

        gsv_start = plan.get("gsv_start_year")
        if gsv_start and policy_year < gsv_start:
            return SurrenderResult(
                gsv=0, ssv_estimate=0, payable=0,
                premiums_paid_total=annual_premium * policy_year,
                loss_on_surrender=annual_premium * policy_year,
                recommendation=f"Policy has not acquired surrender value yet. Minimum {gsv_start} years required.",
                irr_if_surrendered=-100
            )

        # GSV calculation (IRDAI 2024 rules for post-Oct 2024 plans)
        premiums_paid = annual_premium * policy_year
        premiums_for_gsv = annual_premium * (policy_year - 1)  # Exclude 1st year

        # GSV factor based on policy year and term
        gsv_factor = self._get_gsv_factor(policy_year, term)
        gsv = premiums_for_gsv * gsv_factor / 100

        # Add surrender value of bonuses
        vested_bonuses = (sa / 1000) * bonus_rate * policy_year
        bonus_gsv_factor = gsv_factor * 0.9  # Bonus GSV typically slightly lower
        bonus_sv = vested_bonuses * bonus_gsv_factor / 100

        gsv_total = gsv + bonus_sv

        # SSV estimate (typically 10-30% higher than GSV)
        ssv_multiplier = 1.0 + min(0.3, policy_year * 0.02)
        ssv = gsv_total * ssv_multiplier

        payable = max(gsv_total, ssv)

        # Loss analysis
        loss = premiums_paid - payable
        irr = self._calculate_simple_irr(annual_premium, policy_year, payable)

        # Recommendation
        if policy_year < term * 0.5:
            rec = f"HOLD STRONGLY — Only {policy_year}/{term} years completed. IRR improves significantly in later years. Surrendering now = {loss:.0f} rupee loss."
        elif policy_year < term * 0.75:
            rec = f"CONSIDER HOLDING — {policy_year}/{term} years done. Maturity in {term - policy_year} years would yield significantly more."
        else:
            rec = f"HOLD IF POSSIBLE — {policy_year}/{term} years done. Only {term - policy_year} years to maturity. Full bonus + FAB at maturity."

        return SurrenderResult(
            gsv=round(gsv_total, 0),
            ssv_estimate=round(ssv, 0),
            payable=round(payable, 0),
            premiums_paid_total=round(premiums_paid, 0),
            loss_on_surrender=round(loss, 0),
            recommendation=rec,
            irr_if_surrendered=round(irr, 2)
        )

    def _get_gsv_factor(self, policy_year: int, term: int) -> float:
        """GSV factor based on IRDAI 2024 Master Circular minimums."""
        # New IRDAI rules (post Oct 2024)
        ratio = policy_year / term
        if ratio <= 0.1:
            return 30.0
        elif ratio <= 0.2:
            return 35.0
        elif ratio <= 0.3:
            return 50.0
        elif ratio <= 0.5:
            return 55.0
        elif ratio <= 0.7:
            return 65.0
        elif ratio <= 0.9:
            return 75.0
        else:
            return 90.0

    # ---- DEATH BENEFIT CALCULATOR ----
    def calculate_death_benefit(
        self,
        plan: Dict[str, Any],
        sa: float,
        annual_premium: float,
        years_paid: int,
        bonus_rate: float = 42
    ) -> DeathBenefitResult:
        """Calculate death benefit payable."""
        # Get multipliers from plan data
        bsa_mult = plan.get("death_multiplier_bsa_pct") or 125
        ap_mult = plan.get("death_multiplier_ap_x") or 7
        floor_pct = plan.get("death_floor_pct") or 105

        sa_on_death_option1 = sa * bsa_mult / 100  # 125% of BSA
        sa_on_death_option2 = annual_premium * ap_mult  # 7x or 10x AP

        sa_on_death = max(sa_on_death_option1, sa_on_death_option2)

        # Vested bonuses
        bonuses = (sa / 1000) * bonus_rate * years_paid

        # FAB
        fab = self._estimate_fab(sa, years_paid) if years_paid >= 15 else 0

        total = sa_on_death + bonuses + fab

        # Minimum guarantee
        min_guarantee = annual_premium * years_paid * floor_pct / 100

        # Ensure minimum
        total = max(total, min_guarantee)

        formula = f"Max({bsa_mult}% BSA = ₹{sa_on_death_option1:.0f}, {ap_mult}x AP = ₹{sa_on_death_option2:.0f}) + Bonuses ₹{bonuses:.0f} + FAB ₹{fab:.0f}"

        return DeathBenefitResult(
            sa_on_death=round(sa_on_death, 0),
            vested_bonuses=round(bonuses, 0),
            fab_estimate=round(fab, 0),
            total_death_benefit=round(total, 0),
            min_guarantee=round(min_guarantee, 0),
            formula_used=formula
        )

    # ---- LOAN CALCULATOR ----
    def calculate_loan(
        self,
        plan: Dict[str, Any],
        surrender_value: float
    ) -> LoanResult:
        """Calculate maximum loan available."""
        loan_available = str(plan.get("Loan Available", ""))
        if loan_available.startswith("No") or loan_available.startswith("N/A"):
            return LoanResult(
                max_loan=0, interest_rate=0,
                interest_mode="N/A",
                surrender_value_basis=surrender_value
            )

        loan_pct = plan.get("loan_max_pct") or 75
        max_loan = surrender_value * loan_pct / 100

        return LoanResult(
            max_loan=round(max_loan, 0),
            interest_rate=9.50,
            interest_mode="Compounding half-yearly (FY 2024-25 rate)",
            surrender_value_basis=round(surrender_value, 0)
        )

    # ---- PAID-UP VALUE CALCULATOR ----
    def calculate_paid_up(
        self,
        plan: Dict[str, Any],
        sa: float,
        premiums_paid: int,
        total_payable: int,
        bonus_rate: float = 42
    ) -> PaidUpResult:
        """Calculate Paid-Up Sum Assured and reduced benefits."""
        # Paid-Up SA = (premiums paid / total payable) × SA on Maturity
        paid_up_sa = (premiums_paid / total_payable) * sa

        # Vested bonuses remain attached
        bonuses = (sa / 1000) * bonus_rate * premiums_paid

        # Death benefit under paid-up
        death_paid_up = paid_up_sa + bonuses  # No FAB for paid-up

        # Maturity under paid-up
        maturity_paid_up = paid_up_sa + bonuses  # No FAB, no future bonuses

        return PaidUpResult(
            original_sa=sa,
            paid_up_sa=round(paid_up_sa, 0),
            premiums_paid=premiums_paid,
            total_payable=total_payable,
            vested_bonuses=round(bonuses, 0),
            death_benefit_paid_up=round(death_paid_up, 0),
            maturity_paid_up=round(maturity_paid_up, 0)
        )

    # ---- TAX CALCULATOR ----
    def calculate_tax(
        self,
        plan: Dict[str, Any],
        annual_premium: float,
        sa: float,
        maturity_amount: float = 0
    ) -> TaxResult:
        """Calculate tax implications under various sections."""
        category = str(plan.get("Category", ""))

        # Section 80C
        sec80c = str(plan.get("Section 80C", ""))
        is_80c = "Yes" in sec80c
        max_deduction = 150000  # Current 80C limit
        actual_deduction = min(annual_premium, max_deduction) if is_80c else 0

        # Section 10(10D)
        sec10 = str(plan.get("Section 10_10D", ""))
        is_exempt = "Yes" in sec10

        # Check premium-to-SA ratio for exemption
        if is_exempt and annual_premium > 0:
            ratio = annual_premium / sa * 100
            if ratio > 10:
                exemption_condition = f"Premium ({ratio:.1f}% of SA) exceeds 10% limit — maturity may be TAXABLE under new rules"
                is_exempt = False
            else:
                exemption_condition = f"Premium ({ratio:.1f}% of SA) within 10% limit — maturity tax-exempt"
        elif "Annuity" in category or "Pension" in category:
            exemption_condition = "Annuity income is taxable as per income tax slab"
            is_exempt = False
        else:
            exemption_condition = "Standard exemption conditions apply"

        # GST
        gst_rate = plan.get("gst_first_yr_pct") or 4.5

        # TDS
        tds_applicable = maturity_amount > 100000 and not is_exempt
        tds_note = "TDS @ 5% on maturity exceeding ₹1L if premium > 10% of SA (post April 2023)" if tds_applicable else "No TDS applicable"

        return TaxResult(
            section_80c_eligible=is_80c,
            max_80c_deduction=max_deduction,
            actual_deduction=actual_deduction,
            section_10_10d_exempt=is_exempt,
            exemption_condition=exemption_condition,
            gst_rate=gst_rate,
            tds_applicable=tds_applicable,
            tds_note=tds_note
        )

    # ---- IRR CALCULATOR ----
    def calculate_irr(
        self,
        annual_premium: float,
        term: int,
        ppt: int,
        maturity_amount: float,
        survival_benefits: Optional[list] = None
    ) -> IRRResult:
        """
        Calculate Internal Rate of Return using cash flow analysis.
        """
        # Build cash flows
        # Negative = premium payments, Positive = payouts
        cash_flows = []
        for year in range(1, term + 1):
            if year <= ppt:
                cash_flows.append(-annual_premium)
            else:
                cash_flows.append(0)

        # Add survival benefits if any
        if survival_benefits:
            for (year, amount) in survival_benefits:
                if year <= len(cash_flows):
                    cash_flows[year - 1] += amount

        # Add maturity at last year
        cash_flows[-1] += maturity_amount

        total_invested = annual_premium * ppt
        total_returned = maturity_amount + sum(amt for _, amt in (survival_benefits or []))

        # Calculate IRR using Newton's method
        irr = self._solve_irr(cash_flows)

        # Verdict
        if irr < 4.0:
            verdict = "Below FD rates. Consider if the insurance cover justifies the lower return."
        elif irr < 6.0:
            verdict = "Comparable to FD returns (5-6%) with additional life cover benefit."
        elif irr < 7.5:
            verdict = "Good return for a guaranteed insurance product. Better than most FDs after tax."
        else:
            verdict = "Excellent return. Very competitive for a risk-free, tax-exempt instrument."

        wealth_multiple = total_returned / total_invested if total_invested > 0 else 0

        return IRRResult(
            irr_percent=round(irr, 2),
            total_invested=round(total_invested, 0),
            total_returned=round(total_returned, 0),
            wealth_multiple=round(wealth_multiple, 2),
            equivalent_fd_rate=f"{irr + 1.5:.1f}% pre-tax FD (assuming 30% tax bracket)",
            verdict=verdict
        )

    def _solve_irr(self, cash_flows: list, guess: float = 0.05) -> float:
        """Solve IRR using Newton-Raphson method."""
        rate = guess
        for _ in range(1000):
            npv = sum(cf / (1 + rate) ** t for t, cf in enumerate(cash_flows))
            dnpv = sum(-t * cf / (1 + rate) ** (t + 1) for t, cf in enumerate(cash_flows))
            if abs(dnpv) < 1e-12:
                break
            new_rate = rate - npv / dnpv
            if abs(new_rate - rate) < 1e-8:
                rate = new_rate
                break
            rate = new_rate
        return rate * 100

    def _calculate_simple_irr(self, annual_premium: float, years: int, payout: float) -> float:
        """Quick IRR for surrender analysis."""
        if payout <= 0 or years <= 0:
            return -100
        total_paid = annual_premium * years
        if payout >= total_paid:
            return ((payout / total_paid) ** (1 / years) - 1) * 100
        else:
            return -((1 - payout / total_paid) * 100 / years)
