"""
PODDAR JI — Data Layer
Loads the LIC knowledge base and provides fast lookups.
"""
import json
import os
import re
from typing import Optional, List, Dict, Any
from pathlib import Path


class LICKnowledgeBase:
    """
    In-memory indexed knowledge base for all LIC plans.
    Provides O(1) lookups by plan number, UIN, and family.
    """

    def __init__(self, json_path: str = None):
        if json_path is None:
            json_path = os.path.join(os.path.dirname(__file__), "..", "data", "poddar_ji_knowledge_base.json")
        self.plans: List[Dict[str, Any]] = []
        self.by_plan_no: Dict[str, List[Dict]] = {}
        self.by_uin: Dict[str, Dict] = {}
        self.by_family: Dict[str, List[Dict]] = {}
        self.by_status: Dict[str, List[Dict]] = {"Active": [], "Withdrawn": []}
        self.by_category: Dict[str, List[Dict]] = {}
        self._load(json_path)

    def _load(self, path: str):
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        self.plans = data.get("plans", [])
        self.metadata = data.get("metadata", {})

        # Build indices
        for plan in self.plans:
            # By plan number
            pno = str(plan.get("Plan No", "")).strip()
            if pno and pno != "UNKNOWN":
                self.by_plan_no.setdefault(pno, []).append(plan)

            # By UIN
            uin = str(plan.get("UIN", "")).strip()
            if uin and uin != "UNKNOWN":
                self.by_uin[uin] = plan

            # By product family
            family = str(plan.get("Product Family", "")).strip()
            if family and family != "UNKNOWN":
                self.by_family.setdefault(family, []).append(plan)

            # By status
            status = str(plan.get("Status", ""))
            if status in self.by_status:
                self.by_status[status].append(plan)

            # By category
            cat = str(plan.get("Category", ""))
            if cat:
                self.by_category.setdefault(cat, []).append(plan)

    def get_by_plan_no(self, plan_no: int | str) -> List[Dict]:
        """Get all versions of a plan by table number."""
        key = str(plan_no)
        if key in self.by_plan_no:
            return self.by_plan_no[key]
        # Try with .0 suffix (Excel float conversion)
        key_float = f"{float(key)}"
        if key_float in self.by_plan_no:
            return self.by_plan_no[key_float]
        # Try converting
        try:
            key_int = str(int(float(key)))
            for k in self.by_plan_no:
                if k.split('.')[0] == key_int:
                    return self.by_plan_no[k]
        except:
            pass
        return []

    def get_by_uin(self, uin: str) -> Optional[Dict]:
        """Get exact plan by UIN."""
        return self.by_uin.get(uin)

    def get_active_version(self, plan_no: int | str) -> Optional[Dict]:
        """Get the currently active version of a plan number."""
        plans = self.get_by_plan_no(plan_no)
        for p in plans:
            if p.get("Status") == "Active":
                return p
        return plans[0] if plans else None

    def get_family(self, family_name: str) -> List[Dict]:
        """Get all plans in a product family."""
        return self.by_family.get(family_name, [])

    def get_lineage(self, plan_no: int | str) -> Dict[str, Any]:
        """Get full product lineage for a plan."""
        plans = self.get_by_plan_no(plan_no)
        if not plans:
            return {"family": "Unknown", "chain": []}

        plan = plans[0]
        family = plan.get("Product Family", "Unknown")
        family_plans = self.get_family(family)

        # Sort by launch date
        def sort_key(p):
            d = str(p.get("Active From", "9999"))
            m = re.search(r"(\d{4})", d)
            return int(m.group(1)) if m else 9999

        family_plans.sort(key=sort_key)

        chain = []
        for p in family_plans:
            chain.append({
                "plan_no": p.get("Plan No"),
                "uin": p.get("UIN"),
                "name": p.get("Product Name"),
                "period": f"{p.get('Active From', '?')} — {p.get('Active To', 'Present')}",
                "status": p.get("Status"),
                "supersedes": p.get("Supersedes UIN"),
                "superseded_by": p.get("Superseded By UIN"),
            })

        return {"family": family, "chain": chain}

    def get_active_plans(self, category: Optional[str] = None) -> List[Dict]:
        """Get all active plans, optionally filtered by category."""
        plans = self.by_status.get("Active", [])
        if category:
            plans = [p for p in plans if category.lower() in str(p.get("Category", "")).lower()]
        return plans

    def search(self, query: str, limit: int = 10) -> List[Dict]:
        """
        Simple keyword search across plan names, families, and objectives.
        For production, replace with vector similarity search.
        """
        query_lower = query.lower()
        terms = query_lower.split()
        results = []

        for plan in self.plans:
            score = 0
            searchable = " ".join([
                str(plan.get("Product Name", "")),
                str(plan.get("Product Family", "")),
                str(plan.get("Category", "")),
                str(plan.get("Subcategory", "")),
                str(plan.get("Core Objective", "")),
            ]).lower()

            for term in terms:
                if term in searchable:
                    score += 1
                if term in str(plan.get("Product Name", "")).lower():
                    score += 2  # Boost name matches

            if score > 0:
                results.append((score, plan))

        results.sort(key=lambda x: -x[0])
        return [r[1] for r in results[:limit]]

    def get_stats(self) -> Dict[str, Any]:
        """Get database statistics."""
        return {
            "total_plans": len(self.plans),
            "active": len(self.by_status.get("Active", [])),
            "withdrawn": len(self.by_status.get("Withdrawn", [])),
            "families": len(self.by_family),
            "categories": {k: len(v) for k, v in self.by_category.items()},
        }
