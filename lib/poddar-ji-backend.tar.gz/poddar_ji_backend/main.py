"""
PODDAR JI — FastAPI Backend
Complete API for LIC plan lookups, calculations, and recommendations.

Run: uvicorn main:app --host 0.0.0.0 --port 8000 --reload
Docs: http://localhost:8000/docs
"""
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
import os

from core.data_loader import LICKnowledgeBase
from core.calculators import LICCalculatorEngine

# ============================================================
# APP SETUP
# ============================================================
app = FastAPI(
    title="Poddar Ji — LIC Insurance Advisor API",
    description="Complete backend for LIC plan lookups, financial calculations, and intelligent recommendations. Powered by 399 plans × 77 data fields spanning 1956-2026.",
    version="1.0.0",
    contact={"name": "Poddar Ji", "url": "https://poddarji.in"},
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize data and calculator
DATA_PATH = os.path.join(os.path.dirname(__file__), "data", "poddar_ji_knowledge_base.json")
kb = LICKnowledgeBase(DATA_PATH)
calc = LICCalculatorEngine()


# ============================================================
# REQUEST/RESPONSE MODELS
# ============================================================
class PremiumRequest(BaseModel):
    plan_no: int = Field(..., description="LIC Table Number (e.g., 715)")
    age: int = Field(..., ge=0, le=100, description="Entry age")
    term: int = Field(..., ge=5, le=40, description="Policy term in years")
    sa: float = Field(..., gt=0, description="Basic Sum Assured in ₹")
    mode: str = Field("yearly", description="Payment mode: yearly/half_yearly/quarterly/monthly")

class MaturityRequest(BaseModel):
    plan_no: int
    sa: float = Field(..., gt=0)
    term: int = Field(..., ge=5)
    bonus_rate: Optional[float] = Field(None, description="SRB rate per ₹1000 SA. Leave blank for auto-lookup.")

class SurrenderRequest(BaseModel):
    plan_no: int
    policy_year: int = Field(..., ge=1, description="Years completed since policy start")
    annual_premium: float = Field(..., gt=0)
    sa: float = Field(..., gt=0)
    bonus_rate: float = Field(42, description="Average bonus rate per ₹1000 SA")
    term: int = Field(20)

class DeathBenefitRequest(BaseModel):
    plan_no: int
    sa: float = Field(..., gt=0)
    annual_premium: float = Field(..., gt=0)
    years_paid: int = Field(..., ge=0)
    bonus_rate: float = Field(42)

class LoanRequest(BaseModel):
    plan_no: int
    surrender_value: float = Field(..., gt=0)

class PaidUpRequest(BaseModel):
    plan_no: int
    sa: float = Field(..., gt=0)
    premiums_paid: int = Field(..., ge=1)
    total_payable: int = Field(..., ge=1)
    bonus_rate: float = Field(42)

class TaxRequest(BaseModel):
    plan_no: int
    annual_premium: float
    sa: float
    maturity_amount: float = 0

class IRRRequest(BaseModel):
    plan_no: int
    annual_premium: float
    term: int
    ppt: int
    maturity_amount: float
    survival_benefits: Optional[List[List[float]]] = None

class SearchRequest(BaseModel):
    query: str = Field(..., description="Natural language search query")
    limit: int = Field(10, ge=1, le=50)

class RecommendRequest(BaseModel):
    age: int = Field(..., ge=0, le=100)
    income: Optional[float] = None
    goal: str = Field(..., description="Goal: protection/savings/child_education/retirement/tax_saving/wealth")
    budget: Optional[float] = None
    existing_plans: Optional[List[int]] = None

class CompareRequest(BaseModel):
    plans: List[int] = Field(..., min_length=2, max_length=5)
    age: int = 30
    sa: float = 1000000
    term: int = 20


# ============================================================
# HELPER
# ============================================================
def get_plan_or_404(plan_no: int) -> Dict:
    """Get plan by number or raise 404."""
    plans = kb.get_by_plan_no(plan_no)
    if not plans:
        raise HTTPException(404, f"Plan number {plan_no} not found in database")
    # Prefer active version
    for p in plans:
        if p.get("Status") == "Active":
            return p
    return plans[0]


def plan_summary(plan: Dict) -> Dict:
    """Create a clean summary of a plan for API response."""
    return {
        "plan_no": plan.get("Plan No"),
        "name": plan.get("Product Name"),
        "uin": plan.get("UIN"),
        "category": plan.get("Category"),
        "status": plan.get("Status"),
        "product_family": plan.get("Product Family"),
        "premium_type": plan.get("Premium Type"),
        "min_age": plan.get("min_age_int"),
        "max_age": plan.get("max_age_int"),
        "min_sa": plan.get("min_sa_int"),
        "policy_term": plan.get("Policy Term Options"),
        "ppt": plan.get("Premium Paying Term"),
        "death_benefit": plan.get("Death Benefit Formula"),
        "maturity_benefit": plan.get("Maturity Benefit Formula"),
        "survival_benefit": plan.get("Survival Benefit"),
        "bonus_rate": plan.get("Bonus Rate FY2024-25 (per ₹1000 SA)"),
        "guaranteed_additions": plan.get("Guaranteed Additions"),
        "surrender_after": plan.get("Surrender After Years"),
        "loan_available": plan.get("Loan Available"),
        "riders": plan.get("Available Riders"),
        "irr_range": plan.get("Indicative IRR Range"),
        "brochure_url": plan.get("Official Brochure URL"),
        "serviceable": plan.get("Serviceable"),
    }


# ============================================================
# ROUTES: PLAN LOOKUP
# ============================================================
@app.get("/")
def root():
    stats = kb.get_stats()
    return {
        "name": "Poddar Ji — LIC Insurance Advisor API",
        "version": "1.0.0",
        "database": stats,
        "endpoints": {
            "plans": "/api/v1/plans",
            "calculators": "/api/v1/calculate/{type}",
            "search": "/api/v1/search",
            "recommend": "/api/v1/recommend",
            "docs": "/docs"
        }
    }


@app.get("/api/v1/plans")
def list_plans(
    status: Optional[str] = Query(None, description="Filter: Active or Withdrawn"),
    category: Optional[str] = Query(None, description="Filter: Endowment, Term Assurance, etc."),
    limit: int = Query(50, ge=1, le=400)
):
    """List all plans with optional filters."""
    plans = kb.plans
    if status:
        plans = [p for p in plans if p.get("Status", "").lower() == status.lower()]
    if category:
        plans = [p for p in plans if category.lower() in str(p.get("Category", "")).lower()]
    return {
        "count": len(plans[:limit]),
        "total": len(plans),
        "plans": [plan_summary(p) for p in plans[:limit]]
    }


@app.get("/api/v1/plans/{plan_no}")
def get_plan(plan_no: int):
    """Get complete details of a plan by table number."""
    plans = kb.get_by_plan_no(plan_no)
    if not plans:
        raise HTTPException(404, f"Plan {plan_no} not found")
    return {
        "versions": len(plans),
        "plans": [plan_summary(p) for p in plans],
        "full_data": plans  # All 77 fields
    }


@app.get("/api/v1/plans/uin/{uin}")
def get_plan_by_uin(uin: str):
    """Get plan by exact IRDAI UIN."""
    plan = kb.get_by_uin(uin)
    if not plan:
        raise HTTPException(404, f"UIN {uin} not found")
    return plan_summary(plan)


@app.get("/api/v1/plans/{plan_no}/lineage")
def get_lineage(plan_no: int):
    """Get product family lineage — predecessor and successor chain."""
    lineage = kb.get_lineage(plan_no)
    if not lineage["chain"]:
        raise HTTPException(404, f"No lineage found for plan {plan_no}")
    return lineage


@app.get("/api/v1/plans/active/all")
def get_active_plans(category: Optional[str] = None):
    """Get all currently active plans."""
    plans = kb.get_active_plans(category)
    return {
        "count": len(plans),
        "plans": [plan_summary(p) for p in plans]
    }


@app.get("/api/v1/bonus/{plan_no}")
def get_bonus_rate(plan_no: int):
    """Get latest declared bonus rate for a plan."""
    plan = get_plan_or_404(plan_no)
    return {
        "plan_no": plan_no,
        "plan_name": plan.get("Product Name"),
        "bonus_rate_fy2024_25": plan.get("Bonus Rate FY2024-25 (per ₹1000 SA)"),
        "fab_rate": plan.get("FAB Rate"),
        "loyalty_addition": plan.get("Loyalty Addition Rate"),
        "source": plan.get("LIC Bonus Circular URL"),
        "note": "Bonus rates are declared annually by LIC and are not guaranteed for future years."
    }


@app.get("/api/v1/stats")
def get_stats():
    """Get database statistics."""
    return kb.get_stats()


# ============================================================
# ROUTES: CALCULATORS
# ============================================================
@app.post("/api/v1/calculate/premium")
def calculate_premium(req: PremiumRequest):
    """Calculate premium for a plan."""
    plan = get_plan_or_404(req.plan_no)

    # Eligibility check
    min_age = plan.get("min_age_int")
    max_age = plan.get("max_age_int")
    if min_age and req.age < min_age:
        raise HTTPException(400, f"Minimum entry age for Plan {req.plan_no} is {min_age} years. You entered {req.age}.")
    if max_age and max_age < 999 and req.age > max_age:
        raise HTTPException(400, f"Maximum entry age for Plan {req.plan_no} is {max_age} years. You entered {req.age}.")

    result = calc.calculate_premium(plan, req.age, req.term, req.sa, req.mode)
    return {
        "plan_no": req.plan_no,
        "plan_name": plan.get("Product Name"),
        "age": req.age, "term": req.term, "sa": req.sa,
        "premium": result.__dict__,
        "note": "Premium is INDICATIVE. Exact premium depends on underwriting. Consult LIC branch for exact quote.",
        "source": "Estimated from official brochure rate tables where available."
    }


@app.post("/api/v1/calculate/maturity")
def calculate_maturity(req: MaturityRequest):
    """Calculate projected maturity value."""
    plan = get_plan_or_404(req.plan_no)
    result = calc.calculate_maturity(plan, req.sa, req.term, req.bonus_rate)
    return {
        "plan_no": req.plan_no,
        "plan_name": plan.get("Product Name"),
        "sa": req.sa, "term": req.term,
        "maturity": result.__dict__,
    }


@app.post("/api/v1/calculate/surrender")
def calculate_surrender(req: SurrenderRequest):
    """Calculate surrender value and hold-vs-surrender analysis."""
    plan = get_plan_or_404(req.plan_no)
    result = calc.calculate_surrender(plan, req.policy_year, req.annual_premium, req.sa, req.bonus_rate, req.term)
    return {
        "plan_no": req.plan_no,
        "plan_name": plan.get("Product Name"),
        "policy_year": req.policy_year, "term": req.term,
        "surrender": result.__dict__,
    }


@app.post("/api/v1/calculate/death_benefit")
def calculate_death_benefit(req: DeathBenefitRequest):
    """Calculate death benefit payable."""
    plan = get_plan_or_404(req.plan_no)
    result = calc.calculate_death_benefit(plan, req.sa, req.annual_premium, req.years_paid, req.bonus_rate)
    return {
        "plan_no": req.plan_no,
        "plan_name": plan.get("Product Name"),
        "death_benefit": result.__dict__,
    }


@app.post("/api/v1/calculate/loan")
def calculate_loan(req: LoanRequest):
    """Calculate maximum loan available."""
    plan = get_plan_or_404(req.plan_no)
    result = calc.calculate_loan(plan, req.surrender_value)
    return {
        "plan_no": req.plan_no,
        "plan_name": plan.get("Product Name"),
        "loan": result.__dict__,
    }


@app.post("/api/v1/calculate/paid_up")
def calculate_paid_up(req: PaidUpRequest):
    """Calculate paid-up value if premiums are stopped."""
    plan = get_plan_or_404(req.plan_no)
    result = calc.calculate_paid_up(plan, req.sa, req.premiums_paid, req.total_payable, req.bonus_rate)
    return {
        "plan_no": req.plan_no,
        "plan_name": plan.get("Product Name"),
        "paid_up": result.__dict__,
    }


@app.post("/api/v1/calculate/tax")
def calculate_tax(req: TaxRequest):
    """Calculate tax implications."""
    plan = get_plan_or_404(req.plan_no)
    result = calc.calculate_tax(plan, req.annual_premium, req.sa, req.maturity_amount)
    return {
        "plan_no": req.plan_no,
        "plan_name": plan.get("Product Name"),
        "tax": result.__dict__,
    }


@app.post("/api/v1/calculate/irr")
def calculate_irr(req: IRRRequest):
    """Calculate Internal Rate of Return."""
    plan = get_plan_or_404(req.plan_no)
    survival = [(int(s[0]), s[1]) for s in req.survival_benefits] if req.survival_benefits else None
    result = calc.calculate_irr(req.annual_premium, req.term, req.ppt, req.maturity_amount, survival)
    return {
        "plan_no": req.plan_no,
        "plan_name": plan.get("Product Name"),
        "irr": result.__dict__,
    }


# ============================================================
# ROUTES: SEARCH & RECOMMEND
# ============================================================
@app.post("/api/v1/search")
def search_plans(req: SearchRequest):
    """Search plans by natural language query."""
    results = kb.search(req.query, req.limit)
    return {
        "query": req.query,
        "count": len(results),
        "results": [plan_summary(p) for p in results]
    }


@app.post("/api/v1/recommend")
def recommend_plans(req: RecommendRequest):
    """Get personalized plan recommendations based on client profile."""
    recommendations = []

    active_plans = kb.get_active_plans()
    # Filter by eligibility
    eligible = []
    for p in active_plans:
        min_age = p.get("min_age_int")
        max_age = p.get("max_age_int")
        cat = str(p.get("Category", ""))
        if "Group" in cat or "Rider" in cat:
            continue
        if min_age and req.age < min_age:
            continue
        if max_age and max_age < 999 and req.age > max_age:
            continue
        eligible.append(p)

    # Score by goal match
    goal_map = {
        "protection": ["Term Assurance"],
        "savings": ["Endowment"],
        "child_education": ["Child Plan"],
        "retirement": ["Pension/Annuity", "Whole Life"],
        "tax_saving": ["Endowment", "ULIP"],
        "wealth": ["Whole Life", "Endowment"],
        "income": ["Whole Life", "Money Back"],
    }

    target_categories = goal_map.get(req.goal.lower(), ["Endowment"])

    scored = []
    for p in eligible:
        score = 0
        cat = str(p.get("Category", ""))
        for tc in target_categories:
            if tc.lower() in cat.lower():
                score += 10

        # Boost active plans with IRR data
        if p.get("Indicative IRR Range") and p["Indicative IRR Range"] != "N/A":
            score += 3

        # Boost plans with complete data
        if p.get("Death Benefit Formula") and not str(p["Death Benefit Formula"]).startswith("UNKNOWN"):
            score += 2

        if score > 0:
            scored.append((score, p))

    scored.sort(key=lambda x: -x[0])

    for score, p in scored[:5]:
        rec = {
            "plan": plan_summary(p),
            "match_score": score,
            "why": f"Matches your goal of '{req.goal}'. Category: {p.get('Category')}. IRR: {p.get('Indicative IRR Range', 'N/A')}.",
        }
        # Add premium estimate if possible
        if req.budget and p.get("min_age_int"):
            try:
                term = 20 if req.age < 45 else 15
                sa_estimate = req.budget * 15  # Rough SA estimate
                prem = calc.calculate_premium(p, req.age, term, sa_estimate)
                rec["estimated_premium"] = prem.annual
                rec["estimated_sa"] = sa_estimate
            except:
                pass
        recommendations.append(rec)

    return {
        "client_profile": {"age": req.age, "goal": req.goal, "budget": req.budget},
        "eligible_plans": len(eligible),
        "recommendations": recommendations,
        "disclaimer": "Recommendations are indicative. Consult your LIC advisor for personalized advice."
    }


@app.post("/api/v1/compare")
def compare_plans(req: CompareRequest):
    """Side-by-side comparison of multiple plans."""
    comparisons = []
    for pno in req.plans:
        plan = get_plan_or_404(pno)
        # Calculate premium and maturity for comparison
        try:
            prem = calc.calculate_premium(plan, req.age, req.term, req.sa)
            mat = calc.calculate_maturity(plan, req.sa, req.term)
            comparisons.append({
                "plan": plan_summary(plan),
                "premium_annual": prem.annual,
                "premium_total": prem.total_outgo,
                "maturity_projected": mat.total_maturity,
                "irr_range": plan.get("Indicative IRR Range"),
                "wealth_ratio": round(mat.total_maturity / prem.total_outgo, 2) if prem.total_outgo > 0 else 0,
            })
        except Exception as e:
            comparisons.append({
                "plan": plan_summary(plan),
                "error": str(e)
            })

    return {
        "comparison_params": {"age": req.age, "sa": req.sa, "term": req.term},
        "plans": comparisons,
    }


# ============================================================
# HEALTH CHECK
# ============================================================
@app.get("/health")
def health():
    return {
        "status": "healthy",
        "plans_loaded": len(kb.plans),
        "active_plans": len(kb.by_status.get("Active", [])),
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
